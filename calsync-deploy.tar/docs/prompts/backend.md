# Backend Prompt Capture

- GitHub issue: `#32`
- Scope: first Apple-first ChatGPT app slice on top of a small CalSync-owned service for conversational calendar write-back

## Interpreted Requirements

- the first conversational scheduling slice should target the shared iCloud family calendar
- ChatGPT should create, edit, and cancel appointments through CalSync instead of talking to Apple directly
- the service should stay small and focused, but it must preserve normalized local appointment records and Apple event mappings
- the shared workspace should act as the operational brain while iCloud remains the family-visible destination
- the initial tool surface should stay narrow and mutation-focused so the experience is reliable before broader search, planning, or reminder automation ships
- the design should leave room for later Google intake, iCloud Reminders sync, structured medical metadata, and Alexa-style voice input

## Behavioral Boundaries

- this slice is Apple/iCloud-first, not a broad multi-provider conversational assistant
- Google inbound event ingestion is future work
- iCloud Reminders sync is future work
- public booking links and broader availability logic are future work
- the first conversational app should expose create, edit, cancel, and date-range list flows

## Phase Notes

- issue `#32` builds on the preserved write-capable legacy work from earlier CalSync slices, now archived on `legacy/pre-chatgpt-brain-reset`
- the owned service is the durable contract; ChatGPT should never mutate CalDAV directly
- iCloud remains the family-facing calendar of record for day-to-day visibility
- CalSync should keep audit history and local event mappings so the later family workspace can grow without redesigning this slice

## Implemented In This Slice

- FastAPI runtime with `GET /`, `GET /healthz`, appointment mutation routes, and date-range lookup
- `GET /api/appointments` for date-range appointment lookup
- `POST /api/appointments` for appointment creation
- `PATCH /api/appointments/{appointment_id}` for appointment edits
- `POST /api/appointments/{appointment_id}/cancel` for appointment cancellation
- local Postgres persistence for:
  - Apple calendar connection metadata
  - normalized appointments
  - appointment external links
  - audit entries
- Alembic bootstrap migration for the Apple-first schema
- Apple CalDAV adapter that writes `.ics` payloads directly to the configured iCloud calendar URL
- dedicated Cloudflare Worker project in `workers/edge-calsync`
- live Worker route on `edge-calsync.neonbutterfly.net/*`
- Cloudflare KV-backed channel hash validation for `chatgpt`, `shortcuts`, `alexa`, and `webhooks`

## Operational Expectations

- the service requires a configured writable Apple calendar before any mutation route can succeed
- the Apple account should use an app-specific password, not an interactive account password
- the service writes to one designated primary iCloud calendar in this first slice
- appointment changes should update the same Apple provider event rather than recreating a new one
- cancellations should delete the remote Apple event and mark the local record as `cancelled`

## Known Boundaries In Current Code

- no appointment search or availability lookup yet
- list is limited to explicit date windows, not free-form search
- no Google ingestion yet
- no iCloud Reminders sync yet
- no structured medical metadata API fields yet
- no ChatGPT Apps SDK wrapper yet; the Worker is the live edge, but the dedicated ChatGPT app layer is still future work

## First Scheduling UX Requirement

- GitHub issue: `#39`
- interpreted requirement: make the rebooted Apple-first backend usable through a clean family scheduling console instead of only API calls and future design notes

Expected UX behavior:

- `GET /` should render a polished scheduling console
- the root experience should let users create appointments directly into the Apple calendar through CalSync
- existing appointments should be visible, editable, and cancellable from the same console
- the UX should feel like a professional product surface, not a raw API debug page
- the web console should reuse the same appointment service and audit-backed write path as the API and Worker layers

## Scheduling Workspace Polish Requirement

- GitHub issue: `#40`
- interpreted requirement: turn the first scheduling console into a more professional scheduling workspace with clearer browsing, stronger appointment detail, and better product-level information architecture

Expected UX behavior:

- `GET /` should support day, week, and month schedule windows
- the workspace should show a selected appointment detail surface instead of only a flat list
- detail should explain where the appointment lives, when it changed, and what CalSync has done with it
- low-level provider metadata may still exist, but it should stay tucked behind a disclosure instead of dominating the primary experience
- the console should still use the same Apple write-back path for create, edit, and cancel

Expected API/edge support:

- `GET /api/appointments/{appointment_id}` should return the richer appointment detail payload
- `GET /v1/appointments/{appointment_id}` should expose the same detail through the Worker for future channel use

## Cloudflare Deployment Requirement

- GitHub issue: `#35`
- interpreted requirement: evaluate Cloudflare against the rebooted Apple-first service and choose the path that matches the current FastAPI plus Postgres plus Apple CalDAV architecture

Expected deployment behavior:

- publish through Cloudflare Tunnel first if we want Cloudflare in front of the current service
- keep `kayraspi` or another Linux host as the origin until the database is externalized
- do not force this repo into Pages
- do not treat the current codebase as a drop-in Workers deployment
- revisit Cloudflare Containers only after the database/runtime boundary is redesigned

## Cloudflare Edge Worker Requirement

- GitHub issue: `#36`
- interpreted requirement: add a dedicated ChatGPT-first Cloudflare Worker as a thin authenticated edge proxy in front of the Pi-hosted Apple-first origin service

Expected edge behavior:

- deploy a dedicated Worker on its own subdomain such as `edge-calsync.neonbutterfly.net`
- keep the actual scheduling brain on `https://calsync.neonbutterfly.net`
- expose create, update, cancel, and list appointment routes through the Worker
- treat ChatGPT as the first enabled channel
- keep the Worker non-human-facing and machine-only
- keep token source-of-truth on the Pi and sync token hashes into Cloudflare automatically

Current reality:

- the Worker is live on `edge-calsync.neonbutterfly.net`
- the Pi origin now supports the Worker-facing list contract
- the Pi stores channel tokens in `/home/kay/apps/calsync/.runtime/channel-tokens.json`
- Cloudflare KV currently holds the active channel hashes used by the Worker

## Alexa Skill Requirement

- GitHub issue: `#38`
- interpreted requirement: add a first Alexa custom-skill layer on top of the same shared scheduling brain instead of creating a separate voice-only backend

Expected voice behavior:

- Alexa should use the same appointment create, list, cancel, and reschedule flows as other channels
- the first voice slice should support:
  - launch and help
  - create appointment
  - list appointments for a requested day
  - cancel a matching appointment
  - reschedule a matching appointment
- all actual calendar mutation must still happen in the origin service

Expected auth shape:

- the Alexa route should verify signed Alexa web-service requests using Amazon's certificate and request-signature flow
- the Worker should only accept configured Alexa skill IDs from `ALEXA_ALLOWED_SKILL_IDS`
- the route should remain disabled until `ENABLE_ALEXA=true`

Current repo artifacts:

- Worker route: `POST /alexa`
- interaction model: `workers/edge-calsync/alexa/interaction-model.json`
- importable skill package: `workers/edge-calsync/alexa/skill-package`
- voice adapter implementation: `workers/edge-calsync/src/alexa.ts`
- public policy pages on the origin:
  - `GET /privacy`
  - `GET /terms`

Known boundary in this slice:

- this is a first shared-household Alexa adapter, not a full multi-user account-linking platform
